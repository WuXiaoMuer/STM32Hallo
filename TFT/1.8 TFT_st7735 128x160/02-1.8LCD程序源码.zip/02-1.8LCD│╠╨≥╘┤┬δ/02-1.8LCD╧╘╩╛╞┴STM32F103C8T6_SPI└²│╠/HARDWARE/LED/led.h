#ifndef __LED_H
#define __LED_H

#include "sys.h"



#define LED PAout(15)	// PA15

void LED_Init(void);


#endif




