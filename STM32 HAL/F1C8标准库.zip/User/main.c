
#include "stm32f10x.h"                  // Device header
#include "Delay.h"

int main(void) {
    // 开启GPIOC时钟 
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);  

    // GPIO初始化
    GPIO_InitTypeDef GPIO_InitStructure;  
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;       // 推挽输出模式  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_13;             // PC13引脚
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;      
    GPIO_Init(GPIOC, &GPIO_InitStructure);                 // 配置GPIOC

    while (1) {
        // 方法1：使用GPIO_ResetBits/GPIO_SetBits
        GPIO_ResetBits(GPIOC, GPIO_Pin_13);                // PC13低电平
        Delay_ms(500);                                      
        GPIO_SetBits(GPIOC, GPIO_Pin_13);                  // PC13高电平
        Delay_ms(500);                                      

        // 方法2：使用GPIO_WriteBit
        GPIO_WriteBit(GPIOC, GPIO_Pin_13, Bit_RESET);       // PC13低电平  
        Delay_ms(500);                                      
        GPIO_WriteBit(GPIOC, GPIO_Pin_13, Bit_SET);         // PC13高电平  
        Delay_ms(500);                                      

        // 方法3：直接写入0/1
        GPIO_WriteBit(GPIOC, GPIO_Pin_13, (BitAction)0);    // PC13低电平  
        Delay_ms(500);                                      
        GPIO_WriteBit(GPIOC, GPIO_Pin_13, (BitAction)1);    // PC13高电平  
        Delay_ms(500);                                      
    }
}
